<?php
include 'ip.php';
header('Location: forwarding_link/true.html');
exit
?>
